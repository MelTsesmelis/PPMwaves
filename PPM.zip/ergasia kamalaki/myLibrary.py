# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a file for education project in HUA DIT, it:219105

Here is the functions, so my library , I need for this project
"""


from math import log
import matplotlib.pyplot as plt
import numpy as np

    #this function is to convert  a 10-based number to  another base
    #take the number (in 10-based system) and the base to convert
    #return  this number on this base system
def base10To(number, base):
    #Create conversion dictionary
    numberToChar = {i:"0123456789ABCDEF"[i] for i in range(16)}
    
    #set power to largest
    power= int(log(number, base))
   
    #convert number
    converted = ""
    
    for pow in range(power, -1,-1):
        #Divide
        converted += numberToChar[number // (base**pow)]
        #Remainder
        number %= base**pow
        
    #Return
    return converted



    #this function is to count the digits of a number
    #takes a number, make it integer
    #return number of digits
def digitCounter(number):
   digits=0
   n=int(number)
   while (n>0): # for each  digit
       digits+=1  # counter 
       n= n//10   # go for next digit
   return digits  #return the number of the digits


    #this function is to check if a number is divisible by 3
    #takes a number 
    #returns -1  if number is not divisible by 3
    #returns 1 if number is divisible by 3 
def isDivisibleBy3(number):
    #is divisible by 3 when res==1
    res= 1
    if (number%3!=0):
        #is not divisible by 3 when res==-1
       res=-1
    return res


    #this function is to add zeros in front of binary number until digits of the number are devisible by 3 
    #take a number
    #return divisible by 3 number of digits in  this number
def addZeroUntilNumberIsDivisibleBy3(number):
    divisibleNumber= int(number)
    digits= digitCounter(divisibleNumber)
    #if number is not divisible by 3
    if( isDivisibleBy3( digits )== -1 ):
       #add zero on left of number using zfill
       divisibleNumber= number.zfill( digits +1)
            
    #return this number
    return divisibleNumber
      

    #this function is to split by 3 digits an binary number and put per 3 in indexes
    #takes a number
    #return an array, each cell has 3 bits number 
def binaryToArrayPer3(number):  
    binaryLength = digitCounter(number) #use the digitCounter() to count the digits
    n= str(number) #make it string 
    cells = binaryLength // 3 
    
    perThree= [ "" for a  in range(cells)]
   
    if (binaryLength %3 !=0):
        cells+=1
     
    index=0
    for i in range (cells):#for each cell
        for k in range(index,index+3,1): 
                perThree[i] +=  n[index] #put 3 of digits in a cell 
                index+=1
    return perThree


    #this function is to shift left a number 
    #takes a string number
    #returns a shift-lefted as string number
def shiftLeft(string):
    l=len(string)
    d= [ "" for a  in range(l)]
    for i in range(l): 
        d[i-1]= string[i]
    d[l-1]="0"
    
    res=""
    for a in range(len(d)):
        res += d[a]
    return res
    

    #this function is to connect gray code with ppm
    #takes an array
    #return an array with PPM 8  logic each cell
def binaryGrayToPPM(array):
    #create binary array
    #binary =["000","001","010","011","100","101", "110","111"]
    
    binaryGray =["000","001","011","010","110","111", "101","100"]
    #Create PPM code logic
    s="00000001"
    BITS=8 # we need 8 bits
    b= [ "" for a  in range(BITS)] 
    b[BITS-1]=s
    for i in range(BITS-1):
        s=shiftLeft(s)
        b[BITS-i-2]= s # because already i entried b[ last ]
    
    #encode binary number with PPM Code 
    res=[ "" for a  in range(len(array))]
    
    for i in range(len(array)):
      for j in range(len(binaryGray)):
        if (array[i] == binaryGray[j]):
            res[i]=b[j] # b and bin arrays have the same index
                        # so in b[1] we have the code for bin[1]
    return  res

    #this function is to splite an array of string 
    #takes an array 
    #returns splited  array
def splitArrayString(array):
    k=0
    sizeofstring=8
    splited= [ "" for a  in range(sizeofstring*len(array))]
    for i in range (len(array)):
        for j in range(sizeofstring):
            splited[k]=array[i][j]
            k+=1
    return splited
    
    #this function is to find possition of 1 
    #takes an array  , array length to return, and the element to search for
    #returns where this element exists    
def findElementPossition(array,resultArray_length,element):
    elem= str(element)
    index=int(resultArray_length)
    res= [ "" for a  in range(index)]
    k=0
    for i in range(len(array)):
        if (array[i]==elem):
            res[k]= i
            k+=1
    return res
    
            
    #this function is to plot using matplotlib and make a PPM diagram 
    #take   arraybits: and array with all digits of PPM (00001000 10000000 etc)
    #eachSympolLength: is the distance of each symbol  (by default 10)
    #M: the kind of PPM ( Here is by default PPM=8)
    #TS: the pulse time (Here is by default 3*10^(-6))
    #return the diagram of ppm
def plot_GraphOf_PPM(arrayBits,eachSympolLength=10 ,M=8, TS=3*10**(-6)):
    #kleinw ta prohgoumena plots 
    plt.close('all')
    
    #cell per bit
    splited =splitArrayString(arrayBits)
    #o arithmos twn sumbolwn pou exw o opoios sumpiptei me ton aritmo  twn bits tou ppm
    symbolNumber = len(splited)*eachSympolLength
    print("\n\tAll samples --> {x}\n".format(x=symbolNumber ))
    #  gia to shma se μSeconds 
    micro=10**6
   
    # kataskeuazw ton aksona tou y (x(t))
    start=0
    end=  int((symbolNumber*TS*micro) / (M*eachSympolLength)) 
    step= end/symbolNumber
    print("\tstep for graph symbols--> {x}".format(x=step)  )
    y= list(np.repeat(splited,eachSympolLength) )
    #dhmiourgia tou aksona tou t  [microSeconds]
    x= list(np.arange(start,end,step) )
    
    #you can zoom in to see in plot-figure to see better this graph
    plt.figure()
    plt.plot(x,y,marker='o', color='red');
    plt.title(' PPM8')
    plt.xlabel('time [microSec]')
    plt.ylabel('x(t)')
    plt.grid()
    

