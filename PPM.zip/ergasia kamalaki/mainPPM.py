# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a file for education project in HUA DIT 

Create a PPM, M=8 with my it-number : 219105

"""


import myLibrary as mLib



#Arxikopoihseis
base = 2 
am =219105
eachSympolLength=10
arrayBits= mLib.binaryGrayToPPM(  mLib.binaryToArrayPer3(  mLib.base10To( am, base ) ) )
allPeriods = len( mLib.binaryToArrayPer3( mLib.base10To( am, base ) ) )


#Ektupwseis gia debug kai elegxous
print("\n\tMeletis(219105)--> "+mLib.base10To(am,base))
print("\n\tBinary of 219105 has {y} digits".format(y= mLib.digitCounter(mLib.base10To(am,base)) ))
print("\n\tdigit-divible-by-3 is {x}"
      .format( x= mLib.addZeroUntilNumberIsDivisibleBy3( mLib.base10To(am, base) )))
print("\n\tBinary per 3 --> {x}".format(x=mLib.binaryToArrayPer3( mLib.base10To( am, base ) )))   
print("\n\tPPM for 219105\n{x}".format(x=arrayBits))
print("\n\tsplited\n{x}".format(x=mLib.splitArrayString(arrayBits)))
print("\n\tElement '1' possitions  {x}".format(x=mLib.findElementPossition(mLib.splitArrayString(arrayBits),allPeriods,1)))
print("\n\tAll periods {x}".format(x=allPeriods))


#graph
mLib.plot_GraphOf_PPM(arrayBits)

